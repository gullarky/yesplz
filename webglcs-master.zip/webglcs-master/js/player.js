function Player(){
    this.id = Math.round(entityIdSpace * Math.random());
}
